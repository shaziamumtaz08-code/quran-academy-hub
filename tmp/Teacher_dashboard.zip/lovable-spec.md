# 🕌 Al-Quran LMS — Teacher Dashboard Overhaul
## Implementation Spec for Lovable (Existing LMS Integration)

---

## CONTEXT

This is an **existing LMS** built for an online Quran academy running a **1:1 mentorship model**.
The teacher role (`Sana Sanaullah`, role = `Teacher`) is the primary user on mobile.
Most teachers use mobile browsers — this is a **mobile-first** implementation.
The LMS already has: Students, Courses, Attendance, Planning, Salary, Exam Center modules.

**Goal:** Overhaul the teacher dashboard only. Do NOT break existing pages. 
Add new UI components and wire them to existing or new DB tables.

---

## TECH STACK ASSUMPTIONS

- Frontend: React (existing)
- Backend/DB: Supabase (assumed — adjust if different)
- Auth: Existing teacher login session
- Styling: Tailwind CSS (existing)
- Video classes: Zoom (launched via LMS button — keep existing flow)

---

## SECTION 1 — TOP NAVIGATION BAR (Replace existing)

### Current problem
Static header with no useful context.

### New header — 2-row sticky top bar

**Row 1 (slim info strip, dark navy bg):**
- Left: ☪️ Islamic/Hijri date — computed from current date using Hijri conversion algorithm (no external API needed — use Julian Day Number method)
- Center: Live digital clock — `HH:MM:SS AM/PM` — ticking every second via `setInterval`
- Right: Gregorian date — `Tue, 10 March 2026`

**Row 2 (main header):**
- Left: `Al-Quran Academy` label (small caps) + `Assalamu Alaikum, [Teacher First Name] 👋`
- Right: Bell icon with red dot badge (unread notifications count) + Teacher avatar/initials circle

### Hijri conversion function (no library needed):
```javascript
function toHijri(date) {
  // Standard Julian Day Number → Hijri algorithm
  // Returns { day, monthName, year }
  // monthName from: ["Muharram","Safar","Rabi' al-Awwal","Rabi' al-Thani",
  //   "Jumada al-Awwal","Jumada al-Thani","Rajab","Sha'ban",
  //   "Ramadan","Shawwal","Dhul Qi'dah","Dhul Hijjah"]
}
```

---

## SECTION 2 — MISSED ATTENDANCE ALERT BANNER

### Trigger condition
Show when: teacher has classes that occurred in the past (scheduled sessions) where attendance was NOT marked.

### Query needed
```sql
-- Find sessions where:
-- 1. scheduled_date < TODAY
-- 2. attendance record does not exist for that session
-- 3. belongs to this teacher

SELECT s.scheduled_date, st.name as student_name, c.name as course_name
FROM sessions s
JOIN students st ON s.student_id = st.id
JOIN courses c ON s.course_id = c.id
LEFT JOIN attendance a ON a.session_id = s.id
WHERE s.teacher_id = :teacher_id
  AND s.scheduled_date < CURRENT_DATE
  AND a.id IS NULL
ORDER BY s.scheduled_date DESC
LIMIT 10;
```

### UI
- Amber/yellow dismissible banner at top of dashboard content area
- Shows: "⚠️ 3 Attendances Not Marked"
- Lists first 2 entries: `• Roomana Ashraf — Mar 06 (Nazra)`
- "+N more" if more than 2
- CTA button: `Mark Now →` — links to attendance marking flow
- Dismiss (×) button — hides for current session only (not permanent)

---

## SECTION 3 — NEXT CLASS COUNTDOWN (Real-time)

### Current problem
"Next: Nazra with Roomana Ashraf — 4d 2h" is STATIC text. It doesn't count down.

### Fix
Pull next scheduled session from DB. Compute live countdown client-side using `setInterval(1000)`.

### Query needed
```sql
SELECT 
  s.id,
  s.scheduled_datetime,  -- full datetime with time, not just date
  st.name as student_name,
  c.name as course_name,
  c.type as course_type,
  pl.current_position as student_position  -- e.g. "Juz 14 R8" or "Al-Baqarah Ayah 45"
FROM sessions s
JOIN students st ON s.student_id = st.id  
JOIN courses c ON s.course_id = c.id
LEFT JOIN student_progress pl ON pl.student_id = st.id AND pl.course_id = c.id
WHERE s.teacher_id = :teacher_id
  AND s.scheduled_datetime > NOW()
  AND s.status = 'scheduled'
ORDER BY s.scheduled_datetime ASC
LIMIT 1;
```

### UI — Next Class Card
- Dark navy card (turns teal/green when class is same-day)
- Decorative circle in top-right corner (subtle)
- Label: "⏰ Next Class" (changes to "🟢 Coming Up Soon" if same day)
- Student name (bold, large)
- Course name · Current position (e.g. "Nazra · Juz 14 R8")
- **Live countdown boxes:** `[4] DAYS  [2] HRS  [35] MINS` — ticking live
  - When days = 0: show `[HRS] [MINS] [SECS]`
- `🎥 Start` button — launches Zoom class (keep existing Zoom launch logic)

### IMPORTANT
`scheduled_datetime` must store **full timestamp with time** (not just date).
If existing `sessions` table only stores date, add a `scheduled_time` column or migrate to timestamp.

---

## SECTION 4 — STUDENT SMART CARDS (Replace existing student list)

### Current problem
Students are buried inside the Students tab. Teacher must navigate away from dashboard to mark attendance or see student info.

### New: Inline collapsible student cards on dashboard

Each enrolled student gets a card with **two states**:

#### Collapsed (default — always visible):
- Avatar circle (initials, colored)
- Student name + course name + current position
- Attendance % badge (green if ≥85%, amber if <85%)
- Missed sessions count badge (amber, shows if > 0)
- Thin colored progress bar (attendance rate)
- **Two always-visible action buttons:**
  - `✓ Mark Attendance` (teal, primary)
  - `📖 Lesson Log` (outlined)

#### Expanded (tap card header to expand):
- Last lesson covered
- Pace setting (e.g. "10 lines/day")
- `📅 Schedule` button
- `📊 Reports` button

### Query needed
```sql
SELECT 
  st.id, st.name, st.age, st.gender,
  c.name as course_name, c.type,
  sp.current_position,
  sp.pace_per_day,
  COUNT(a.id) FILTER (WHERE a.status = 'present') as sessions_present,
  COUNT(a.id) as total_sessions,
  ROUND(COUNT(a.id) FILTER (WHERE a.status = 'present') * 100.0 / NULLIF(COUNT(a.id), 0)) as attendance_pct,
  -- Missed = scheduled past sessions with no attendance record
  (SELECT COUNT(*) FROM sessions s2 
   LEFT JOIN attendance a2 ON a2.session_id = s2.id
   WHERE s2.student_id = st.id AND s2.teacher_id = :teacher_id
   AND s2.scheduled_datetime < NOW() AND a2.id IS NULL) as missed_count,
  al.lesson_description as last_lesson,
  al.created_at as last_lesson_date
FROM enrollments e
JOIN students st ON e.student_id = st.id
JOIN courses c ON e.course_id = c.id
LEFT JOIN student_progress sp ON sp.student_id = st.id AND sp.course_id = c.id
LEFT JOIN attendance a ON a.student_id = st.id AND a.teacher_id = :teacher_id
LEFT JOIN LATERAL (
  SELECT lesson_description, created_at FROM attendance
  WHERE student_id = st.id AND teacher_id = :teacher_id
  ORDER BY created_at DESC LIMIT 1
) al ON true
WHERE e.teacher_id = :teacher_id AND e.status = 'active'
GROUP BY st.id, st.name, st.age, st.gender, c.name, c.type, 
         sp.current_position, sp.pace_per_day, al.lesson_description, al.created_at;
```

---

## SECTION 5 — ATTENDANCE MARKING MODAL (Upgrade existing)

### Trigger
Tap `✓ Mark Attendance` on any student card → bottom sheet slide-up modal.

### Modal structure (top to bottom):

#### 1. Student header
- Avatar + name + course

#### 2. ⚠️ PLAN NOT SUBMITTED BANNER (conditional)
Show ONLY if: current month's planning form has NOT been submitted for this student.

```sql
SELECT COUNT(*) FROM monthly_plans
WHERE student_id = :student_id
  AND teacher_id = :teacher_id
  AND plan_month = DATE_TRUNC('month', CURRENT_DATE)
  AND status IN ('submitted', 'approved');
```
If count = 0 → show amber banner:
- Title: "March Plan Not Submitted"
- Body: "[Student name]'s monthly planning form for [Month Year] is pending. Should be filled by month-end."
- CTA: `Fill Plan Now →` (links to existing Planning form for this student)

#### 3. 📘 LAST MONTH'S PLAN CONTEXT PANEL (always show if plan exists)

```sql
SELECT 
  mp.plan_month,
  mp.subject,
  mp.from_position,
  mp.to_position, 
  mp.monthly_target,
  mp.notes,
  mp.status,
  mp.approved_on,
  sp.current_position as current_actual
FROM monthly_plans mp
LEFT JOIN student_progress sp ON sp.student_id = mp.student_id AND sp.course_id = mp.course_id
WHERE mp.student_id = :student_id
  AND mp.teacher_id = :teacher_id
ORDER BY mp.plan_month DESC
LIMIT 1;
```

Display:
- Header: "📖 Monthly Plan — [Last Month]" + status badge (Approved/Pending)
- Position row: `START: [from_position]` → `TARGET: [to_position]`
- Two mini boxes: `CURRENTLY AT: [current_actual]` | `MONTHLY TARGET: [monthly_target]`
- Teacher's note from plan in italic quote block with left border

#### 4. Divider line

#### 5. Today's attendance status toggle
Three buttons: `✓ Present` | `✗ Absent` | `⏱ Late`

#### 6. Lesson Covered input (optional)
- Text input
- Placeholder pre-filled from `current_actual` position (e.g. "e.g. Juz 14 R8")
- On save: update `student_progress.current_position` with this value

#### 7. Notes textarea (optional)
- Placeholder: "Student was struggling with tajweed..."

#### 8. `Save Attendance` button (teal, full width)

#### On save — write to DB:
```sql
INSERT INTO attendance (
  session_id, student_id, teacher_id, course_id,
  status, lesson_covered, notes, marked_at
) VALUES (
  :session_id, :student_id, :teacher_id, :course_id,
  :status, :lesson_covered, :notes, NOW()
);

-- Also update current position if lesson_covered was filled:
UPDATE student_progress 
SET current_position = :lesson_covered, updated_at = NOW()
WHERE student_id = :student_id AND course_id = :course_id;
```

#### Confirmation screen (replaces modal content on save):
- ✅ icon
- "Attendance Marked!" + student name + today's date
- If plan still pending → reminder note: "📋 Don't forget — [Month] plan for [Student] is still pending!"
- `Done` button closes modal

---

## SECTION 6 — QUICK ACTIONS STRIP

4 buttons in a 2×2 grid below student cards:

| Button | Action |
|--------|--------|
| 🎥 Start Class | Launch Zoom (existing logic) |
| ✅ Mark Attendance | Open student selector → then attendance modal |
| 📖 Lesson Log | Navigate to existing lesson log page |
| 📊 Reports | Navigate to existing reports page |

---

## SECTION 7 — STATS ROW (Replace existing 5-box layout)

Replace 5 large boxes with 3 compact boxes in one row:

| Box | Data | Query |
|-----|------|-------|
| Sessions | Count of attendance records this month for this teacher | `SELECT COUNT(*) FROM attendance WHERE teacher_id = :id AND DATE_TRUNC('month', marked_at) = DATE_TRUNC('month', NOW())` |
| Attendance % | Avg attendance rate across all active students | `SELECT AVG(attendance_pct) FROM [student card query above]` |
| Students | Count of active enrollments | `SELECT COUNT(*) FROM enrollments WHERE teacher_id = :id AND status = 'active'` |

---

## SECTION 8 — BOTTOM NAVIGATION (Replace hamburger menu)

Replace or supplement the existing hamburger (≡) menu with a persistent bottom nav bar:

| Tab | Icon | Destination |
|-----|------|-------------|
| Home | 🏠 | Dashboard (this page) |
| Students | 👩‍🎓 | Existing Students page |
| Planning | 📅 | Existing Planning page |
| Salary | 💰 | Existing Salary Engine page |

Active tab: teal color + small underline indicator dot.

---

## DATABASE CHANGES REQUIRED

### New columns needed (check if already exist):

```sql
-- sessions table: ensure full timestamp exists
ALTER TABLE sessions ADD COLUMN IF NOT EXISTS scheduled_datetime TIMESTAMPTZ;
-- Migrate from date + time if stored separately

-- monthly_plans table: ensure these columns exist
ALTER TABLE monthly_plans ADD COLUMN IF NOT EXISTS from_position TEXT;
ALTER TABLE monthly_plans ADD COLUMN IF NOT EXISTS to_position TEXT;
ALTER TABLE monthly_plans ADD COLUMN IF NOT EXISTS monthly_target TEXT;
ALTER TABLE monthly_plans ADD COLUMN IF NOT EXISTS plan_month DATE; -- first day of month
ALTER TABLE monthly_plans ADD COLUMN IF NOT EXISTS approved_on DATE;

-- student_progress table: ensure this exists
CREATE TABLE IF NOT EXISTS student_progress (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  student_id UUID REFERENCES students(id),
  course_id UUID REFERENCES courses(id),
  teacher_id UUID REFERENCES teachers(id),
  current_position TEXT,    -- e.g. "Juz 14 R8" or "Al-Baqarah Ayah 45" or "Takhti 11, Page 21"
  pace_per_day TEXT,        -- e.g. "10 lines/day"
  updated_at TIMESTAMPTZ DEFAULT NOW(),
  UNIQUE(student_id, course_id)
);
```

---

## WHAT NOT TO CHANGE

- Existing Attendance page (full detail view) — keep as is
- Existing Students detail page — keep as is
- Existing Planning form — keep as is, just link to it from banner
- Existing Zoom launch logic — keep exactly as is
- All other teacher pages (Exam Center, Reports, Salary Engine)
- Admin/supervisor views — not in scope

---

## UI DESIGN REFERENCE

A working React prototype of this dashboard has been built. Key design tokens:

```javascript
const COLORS = {
  navy:      "#0D1B2A",  // primary dark (header, cards)
  navyMid:   "#1B2E45",  // secondary dark
  teal:      "#1A8C6E",  // primary action color
  tealLight: "#22A882",  // hover/accent
  gold:      "#C8960C",  // warnings/amber
  goldLight: "#F0B429",  // warning borders
  alert:     "#E05C5C",  // errors/absent
  sky:       "#3B9ED8",  // info/secondary actions
  bg:        "#F4F6F9",  // page background
  card:      "#FFFFFF",  // card background
  muted:     "#8A97A8",  // secondary text
  border:    "#E2E8F0",  // card borders
};
```

Border radius: 14–18px for cards, 10–12px for buttons and inputs.
Font: System font stack (Nunito preferred if available).
Shadows: `0 2px 12px rgba(0,0,0,0.06)` for cards.

---

## PRIORITY ORDER FOR IMPLEMENTATION

1. **Real-time countdown** (Section 3) — highest visible impact
2. **Attendance modal with plan context** (Section 5) — core workflow
3. **Missed attendance banner** (Section 2) — accountability
4. **Student smart cards on dashboard** (Section 4) — removes need to leave dashboard
5. **Live dual-date header** (Section 1) — Islamic context
6. **Stats row cleanup** (Section 7) — polish
7. **Bottom nav** (Section 8) — navigation UX
8. **Quick actions grid** (Section 6) — convenience

---

## NOTES FOR DEVELOPER

- The prototype JSX file (`teacher-dashboard.jsx`) is available as a complete working reference. Use it for component structure and interaction patterns — wire the hardcoded data to real Supabase queries.
- All student data in the prototype is **mock data** — replace with real queries per Section 4.
- The `planFilled: false` flag in the prototype maps to the plan submission check query in Section 5.2.
- Monthly plan "last month" logic: always show the most recently approved plan, regardless of month — not strictly "last calendar month."
- The attendance modal is a **bottom sheet** (slides up from bottom), not a centered dialog — important for mobile UX.
- Countdown must use the `scheduled_datetime` timestamp, not just the date.

---

*Prepared by: System Analyst / Al-Quran Academy LMS Project*
*Date: March 2026*
*Reference prototype: teacher-dashboard.jsx*
